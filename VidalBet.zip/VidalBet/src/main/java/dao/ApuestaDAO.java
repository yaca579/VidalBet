/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
/**
 *
 * @author plugx
 */
public class ApuestaDAO {
public int guardarApuestaYObtenerId(int idUsuario, double importe, double cuota, double premio) {
    String sql = "INSERT INTO apuestas (id_usuario, importe, cuota, premio_posible, estado) VALUES (?, ?, ?, ?, 'pendiente')";
    
    // Añadimos RETURN_GENERATED_KEYS para que MySQL nos diga el ID
    try (Connection cn = Conexion.getConexion();
         PreparedStatement ps = cn.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {
        
        ps.setInt(1, idUsuario);
        ps.setDouble(2, importe);
        ps.setDouble(3, cuota);
        ps.setDouble(4, premio);
        ps.executeUpdate();
        
        // Recuperamos el ID que ha creado MySQL
        var rs = ps.getGeneratedKeys();
        if (rs.next()) {
            return rs.getInt(1); // Devolvemos el ID (ej: 8, 9, 10...)
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return -1; // Si falla, devuelve -1
}
public void actualizarEstadoApuesta(int idApuesta, String nuevoEstado) {
    String sql = "UPDATE apuestas SET estado = ? WHERE id_apuesta = ?";
    
    try (Connection cn = Conexion.getConexion();
         java.sql.PreparedStatement ps = cn.prepareStatement(sql)) {
        
        ps.setString(1, nuevoEstado);
        ps.setInt(2, idApuesta);
        ps.executeUpdate();
        
        System.out.println("DEBUG: DB actualizada con éxito a " + nuevoEstado);
        
    } catch (Exception e) {
        System.out.println("Error al actualizar estado: " + e.getMessage());
    } 
}
public double obtenerSaldoUsuario(int idUsuario) {
    String sql = "SELECT saldo FROM usuarios WHERE id_usuario = ?";
    double saldo = 0.0;

    try (Connection cn = Conexion.getConexion();
         java.sql.PreparedStatement ps = cn.prepareStatement(sql)) {
        
        ps.setInt(1, idUsuario);
        var rs = ps.executeQuery();
        
        if (rs.next()) {
            saldo = rs.getDouble("saldo");
        }
    } catch (Exception e) {
        System.out.println("Error al obtener saldo: " + e.getMessage());
    }
    return saldo;
}

// METODOS PARA LA PANTALLA DE INICIO

public boolean registrarUsuario(String nombre, String password, double saldoInicial) {
    String sql = "INSERT INTO usuarios (nombre, password, saldo) VALUES (?, ?, ?)";
    try (Connection cn = Conexion.getConexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        
        ps.setString(1, nombre);
        ps.setString(2, password);
        ps.setDouble(3, saldoInicial);
        
        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        System.out.println("Error al registrar usuario: " + e.getMessage());
        return false;
    }
}
public int login(String nombre, String password) {
    String sql = "SELECT id_usuario FROM usuarios WHERE nombre = ? AND password = ?";
    try (Connection cn = Conexion.getConexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        
        ps.setString(1, nombre);
        ps.setString(2, password);
        var rs = ps.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id_usuario");
        }
    } catch (Exception e) {
        System.out.println("Error en login: " + e.getMessage());
    }
    return -1;
}

// VER HISTORIAL DE APUESTAS

public java.util.List<String[]> obtenerHistorial(int idUsuario) {
    java.util.List<String[]> historial = new java.util.ArrayList<>();
    String sql = "SELECT id_apuesta, importe, cuota, premio_posible, estado FROM apuestas WHERE id_usuario = ? ORDER BY id_apuesta DESC";
    
    try (Connection cn = Conexion.getConexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        
        ps.setInt(1, idUsuario);
        var rs = ps.executeQuery();
        
        while (rs.next()) {
            String[] fila = {
                String.valueOf(rs.getInt("id_apuesta")),
                String.valueOf(rs.getDouble("importe")),
                String.valueOf(rs.getDouble("cuota")),
                String.valueOf(rs.getDouble("premio_posible")),
                rs.getString("estado")
            };
            historial.add(fila);
        }
    } catch (Exception e) {
        System.out.println("Error al obtener historial: " + e.getMessage());
    }
    return historial;
}

//PARA RECARGAR SALDO

public boolean recargarSaldo(int idUsuario, double monto) {
    String sql = "UPDATE usuarios SET saldo = saldo + ? WHERE id_usuario = ?";
    try (Connection cn = Conexion.getConexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        
        ps.setDouble(1, monto);
        ps.setInt(2, idUsuario);
        
        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        System.out.println("Error al recargar saldo: " + e.getMessage());
        return false;
    }
}

// OBTENER EL NOMBRE AL LADO DEL SALDO

public String obtenerNombreUsuario(int idUsuario) {
    String sql = "SELECT nombre FROM usuarios WHERE id_usuario = ?";
    try (Connection cn = Conexion.getConexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        ps.setInt(1, idUsuario);
        var rs = ps.executeQuery();
        if (rs.next()) return rs.getString("nombre");
    } catch (Exception e) { e.printStackTrace(); }
    return "Desconocido";
}

}
