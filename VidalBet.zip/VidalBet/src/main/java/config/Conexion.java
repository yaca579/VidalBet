/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author plugx
 */
public class Conexion {
private static final String URL = "jdbc:mysql://localhost:3306/vidalbet";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // Tu pass está vacía

    public static Connection getConexion() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.err.println("❌ Error: ¿Has encendido MySQL? " + e.getMessage());
            return null;
        }
    }    
}
